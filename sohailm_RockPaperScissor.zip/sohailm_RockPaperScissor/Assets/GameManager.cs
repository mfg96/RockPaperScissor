﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{

    enum elements {Scissors=1, Rock=3, Paper=2}

    private int PChoice =-1;
    private int AIChoice=-1;  
    private bool pturn=true;

    public GameObject WinnerTxt;
    public Sprite PprImg, RckImg, ScrImg;
    public GameObject AIimg;

    
    // Update is called once per frame
    void Update()
    {
        if(pturn && PChoice == -1)
        return;
        else{
            AI();
            Check();
            PChoice=-1;
            pturn=true;

        }
    }
    public void pChoice(int c){
        PChoice=c;
        pturn=false;
    }

    public void AI(){

        AIChoice=Random.Range(1,4);

        if (AIChoice == 1)
        {
            AIimg.GetComponent<UnityEngine.UI.Image>().sprite = ScrImg;
        }
        if (AIChoice == 2)
        {
            AIimg.GetComponent<UnityEngine.UI.Image>().sprite = PprImg;
        }
        if (AIChoice == 3)
        {
            AIimg.GetComponent<UnityEngine.UI.Image>().sprite = RckImg;
        }
    }


    void Check(){
        if(PChoice==AIChoice){
            //draw
            //WinnerTxt.GetComponent<Text>().text="Draw";
            WinnerTxt.GetComponent<UnityEngine.UI.Text>().text = "Draw";
        }
       else if(PChoice==(int)elements.Paper && AIChoice==(int)elements.Rock){
            //player wins
            //WinnerTxt.GetComponent<Text>().text="Player Wins";
            WinnerTxt.GetComponent<UnityEngine.UI.Text>().text = "Player Wins";
            //WinnerTxt.GetComponent<GUIText>().text = "pla wins";
        }
        else if(PChoice==(int)elements.Rock && AIChoice==(int)elements.Paper){
            //AI wins
            //WinnerTxt.GetComponent<Text>().text="AI Wins";
            WinnerTxt.GetComponent<UnityEngine.UI.Text>().text = "AI Wins";
            
           
        }
        else if(PChoice==(int)elements.Scissors && AIChoice==(int)elements.Rock){

            //AI wins
            //WinnerTxt.GetComponent<Text>().text="AI Wins";
            WinnerTxt.GetComponent<UnityEngine.UI.Text>().text = "AI Wins";
        }
        else if(PChoice==(int)elements.Scissors && AIChoice==(int)elements.Paper){

            //Player wins
            //WinnerTxt.GetComponent<Text>().text="Player Wins";
            WinnerTxt.GetComponent<UnityEngine.UI.Text>().text = "Player Wins";
        }
        else if(PChoice==(int)elements.Paper && AIChoice==(int)elements.Scissors){
            
            //AI wins
            //WinnerTxt.GetComponent<Text>().text="AI Wins";
            WinnerTxt.GetComponent<UnityEngine.UI.Text>().text = "AI Wins";
        }
        else if(PChoice==(int)elements.Rock && AIChoice==(int)elements.Scissors){
            
            //Player wins
            //WinnerTxt.GetComponent<Text>().text="Player Wins";
            WinnerTxt.GetComponent<UnityEngine.UI.Text>().text = "Player Wins";
        }

    }
}
